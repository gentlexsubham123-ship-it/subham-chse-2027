SUBHAM CHSE 2027 — PWA site bundle

PUBLISHING:
1. Create a GitHub repository named subham-chse-2027 (public if using GitHub Free Pages).
2. Upload every file and folder in this ZIP to the repository root. Keep index.html at the root.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
5. Wait for the deployment and tap Visit site. The URL will look like:
   https://YOUR-GITHUB-USERNAME.github.io/subham-chse-2027/
6. Share that URL with friends. On Android Chrome, open it > ⋮ > Add to Home screen / Install app.

NOTES:
- The repository and published site are public. Do not upload private information.
- This is a Progressive Web App starter. Its current reminders rely on the page being active;
  this does NOT provide guaranteed native alarms when the browser is closed or the phone sleeps.
- For Play Store release, build and test an Android package (for example with a Trusted Web Activity),
  complete Play Console requirements, and use an eligible adult account holder if the publisher is under 18.
